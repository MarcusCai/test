//
//  NotificationService.h
//  XGService
//
//  Created by uwei on 09/08/2017.
//  Copyright © 2017 tyzual. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

/// An object that modifies the content of a remote notification before it's delivered to the user.
@interface NotificationService : UNNotificationServiceExtension

@end
