//
//  TPNSApiConfig.m
//  TPNS-Demo-Cloud
//
//  Created by rockzuo on 2023/2/23.
//  Copyright © 2023 XG of Tencent. All rights reserved.
//

#import "TPNSApiConfig.h"
#import "AppDelegate+XGConfig.h"

/// TPNS 集群配置参数
@implementation TPNSCluster
@end

@implementation TPNSApiConfig

/// 接口分类
+ (NSArray *)apiSectionList {
    return @[
        NSLocalizedString(@"account_section", nil), NSLocalizedString(@"tag_section", nil), NSLocalizedString(@"attributes_section", nil),
        NSLocalizedString(@"app_section", nil), NSLocalizedString(@"local_notification_section", nil),
        NSLocalizedString(@"live_activity_section", nil),
#ifdef TPNS_VoIP
        NSLocalizedString(@"voip_section", nil)
#endif
    ];
}

/// 分类下的具体接口
+ (NSArray<NSArray *> *)apiRowList {
    return @[
        @[ NSLocalizedString(@"bind_account", nil), NSLocalizedString(@"unbind_account", nil), NSLocalizedString(@"clear_account", nil) ],
        @[
            NSLocalizedString(@"bind_tag", nil), NSLocalizedString(@"unbind_tag", nil), NSLocalizedString(@"update_tag", nil),
            NSLocalizedString(@"clear_tag", nil), NSLocalizedString(@"query_tag", nil)
        ],
        @[
            NSLocalizedString(@"bind_attributes", nil), NSLocalizedString(@"unbind_attributes", nil), NSLocalizedString(@"update_attributes", nil),
            NSLocalizedString(@"clear_attributes", nil)
        ],
        @[
            NSLocalizedString(@"register_app", nil), NSLocalizedString(@"unregister_app", nil), NSLocalizedString(@"device_token", nil),
            NSLocalizedString(@"set_badge", nil), NSLocalizedString(@"upload_log", nil)
        ],
        @[
            NSLocalizedString(@"add_notification", nil), NSLocalizedString(@"remove_notification", nil),
            NSLocalizedString(@"search_notification", nil)
        ],
        @[ NSLocalizedString(@"sync_live_activity", nil) ],
#ifdef TPNS_VoIP
        @[
            NSLocalizedString(@"start_in_voip", nil), NSLocalizedString(@"end_in_voip", nil), NSLocalizedString(@"start_out_voip", nil),
            NSLocalizedString(@"end_out_voip", nil)
        ]
#endif
    ];
}

/// 账号类型名称
+ (NSArray *)accountTypeNameList {
    return @[
        @"account_type_unknow", @"account_type_custom", @"account_type_idfa", @"account_type_phone_number", @"account_type_wechat",
        @"account_type_qq", @"account_type_email", @"account_type_sina_webo", @"account_type_alipay", @"account_type_taobao", @"account_type_douban",
        @"account_type_facebook", @"account_type_twitter", @"account_type_google", @"account_type_baidu", @"account_type_jd", @"account_type_linkin"
    ];
}

/// 账号类型
+ (NSArray *)accountTypeList {
    return @[
        @(XGPushTokenAccountTypeUNKNOWN), @(XGPushTokenAccountTypeCUSTOM), @(XGPushTokenAccountTypeIDFA), @(XGPushTokenAccountTypePHONE_NUMBER),
        @(XGPushTokenAccountTypeWX_OPEN_ID), @(XGPushTokenAccountTypeQQ_OPEN_ID), @(XGPushTokenAccountTypeEMAIL), @(XGPushTokenAccountTypeSINA_WEIBO),
        @(XGPushTokenAccountTypeALIPAY), @(XGPushTokenAccountTypeTAOBAO), @(XGPushTokenAccountTypeDOUBAN), @(XGPushTokenAccountTypeFACEBOOK),
        @(XGPushTokenAccountTypeTWITTER), @(XGPushTokenAccountTypeGOOGLE), @(XGPushTokenAccountTypeBAIDU), @(XGPushTokenAccountTypeJINGDONG),
        @(XGPushTokenAccountTypeLINKEDIN)
    ];
}

/// TPNS集群列表
+ (NSArray *)clusterList {
    //初始化广州集群
    TPNSCluster *gz = [[TPNSCluster alloc] init];
    gz.accessID = TPNS_ACCESS_ID;
    gz.accessKey = TPNS_ACCESS_KEY;
    gz.domainName = @"tpns.tencent.com";
    gz.clusterName = NSLocalizedString(@"cluster_type_gz", nil);

    //初始化上海集群
    TPNSCluster *sh = [[TPNSCluster alloc] init];
    sh.accessID = 1680001003;
    sh.accessKey = @"IG589D1V9RDA";
    sh.domainName = @"tpns.sh.tencent.com";
    sh.clusterName = NSLocalizedString(@"cluster_type_sh", nil);

    //初始化香港集群
    TPNSCluster *hk = [[TPNSCluster alloc] init];
    hk.accessID = 1630001123;
    hk.accessKey = @"I1UTM0SPK1WP";
    hk.domainName = @"tpns.hk.tencent.com";
    hk.clusterName = NSLocalizedString(@"cluster_type_hk", nil);

    //初始化新加坡集群
    TPNSCluster *xjp = [[TPNSCluster alloc] init];
    xjp.accessID = 1600001051;
    xjp.accessKey = @"I6UTH9Y5WI52";
    xjp.domainName = @"tpns.sgp.tencent.com";
    xjp.clusterName = NSLocalizedString(@"cluster_type_sgp", nil);

    return @[ gz, sh, hk, xjp ];
}

@end
