//
//  TPNSApiConfig.h
//  TPNS-Demo-Cloud
//
//  Created by rockzuo on 2023/2/23.
//  Copyright © 2023 XG of Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 绑定账号的类型
typedef NS_ENUM(NSUInteger, XGPushTokenAccountType) {
    XGPushTokenAccountTypeUNKNOWN = (0),         // 默认类型，单账号绑定默认使用
    XGPushTokenAccountTypeCUSTOM = (1),          // 自定义
    XGPushTokenAccountTypeIDFA = (1001),         // 广告唯一标识 IDFA
    XGPushTokenAccountTypePHONE_NUMBER = (1002), // 手机号码
    XGPushTokenAccountTypeWX_OPEN_ID = (1003),   // 微信 OPENID
    XGPushTokenAccountTypeQQ_OPEN_ID = (1004),   // QQ OPENID
    XGPushTokenAccountTypeEMAIL = (1005),        // 邮箱
    XGPushTokenAccountTypeSINA_WEIBO = (1006),   // 新浪微博
    XGPushTokenAccountTypeALIPAY = (1007),       // 支付宝
    XGPushTokenAccountTypeTAOBAO = (1008),       // 淘宝
    XGPushTokenAccountTypeDOUBAN = (1009),       // 豆瓣
    XGPushTokenAccountTypeFACEBOOK = (1010),     // FACEBOOK
    XGPushTokenAccountTypeTWITTER = (1011),      // TWITTER
    XGPushTokenAccountTypeGOOGLE = (1012),       // GOOGLE
    XGPushTokenAccountTypeBAIDU = (1013),        // 百度
    XGPushTokenAccountTypeJINGDONG = (1014),     // 京东
    XGPushTokenAccountTypeLINKEDIN = (1015)      // LINKEDIN
};

typedef NS_ENUM(NSInteger, TagOperationType) { Add = 0, Delete = 1, Update = 2, Clear = 3, Query = 4 };
typedef NS_ENUM(NSInteger, AccountOperationType) { AccountAdd = 0, AccountDelete = 1, AccountClear = 2 };
typedef NS_ENUM(NSInteger, AttributeOperationType) { AttributeAdd = 0, AttributeDelete = 1, AttributeUpdate = 2, AttributeClear = 3 };
typedef NS_ENUM(NSInteger, VoIPCallOperationType) { VoIPCallIN = 0, VoIPCallOUT = 1, VoIPCallEnd = 2 };

/// TPNS接口配置类
@interface TPNSApiConfig : NSObject

/// 接口分类
+ (NSArray *)apiSectionList;

/// 分类下的具体接口
+ (NSArray<NSArray *> *)apiRowList;

/// 账号类型名称
+ (NSArray *)accountTypeNameList;

/// 账号类型
+ (NSArray *)accountTypeList;

/// TPNS集群列表
+ (NSArray *)clusterList;

@end

/// TPNS 集群配置参数
@interface TPNSCluster : NSObject
/// 通过TPNS管理台申请的 accessID
@property (assign, nonatomic) uint32_t accessID;
/// 通过TPNS管理台申请的 accessKey
@property (strong, nonatomic) NSString *accessKey;
/// 非广州集群，请开启对应集群配置（广州集群无需使用），此函数需要在startXGWithAccessID函数之前调用
@property (strong, nonatomic) NSString *domainName;
/// 集群名称
@property (strong, nonatomic) NSString *clusterName;
@end

NS_ASSUME_NONNULL_END
