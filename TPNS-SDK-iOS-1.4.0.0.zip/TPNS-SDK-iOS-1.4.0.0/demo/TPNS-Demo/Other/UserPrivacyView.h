//
//  UserPrivacyView.h
//  TPNS-Demo-Cloud
//
//  Created by rockzuo on 2021/5/19.
//  Copyright © 2021 XG of Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UserPrivacyView : UIView

@property (nonatomic, strong) void (^agreeHander)(void);

@end

NS_ASSUME_NONNULL_END
