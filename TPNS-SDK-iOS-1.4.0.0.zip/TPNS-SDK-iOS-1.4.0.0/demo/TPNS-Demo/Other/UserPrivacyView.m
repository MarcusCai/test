//
//  UserPrivacyView.m
//  TPNS-Demo-Cloud
//
//  Created by rockzuo on 2021/5/19.
//  Copyright © 2021 XG of Tencent. All rights reserved.
//

#import "UserPrivacyView.h"
#import "XGPush.h"
#import "AppDelegate+XGConfig.h"
#import "TPNSCommonMethod.h"

@implementation UserPrivacyView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupUI];
    }
    return self;
}

- (void)setupUI {
    self.backgroundColor = [[UIColor alloc] initWithWhite:0 alpha:0.3];
    UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake((TPNS_SCREEN_WIDTH - 260) / 2, (TPNS_SCREEN_HEIGHT - 300) / 2, 260, 290)];
    contentView.backgroundColor = [UIColor whiteColor];
    contentView.layer.cornerRadius = 8;
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(8, 12, contentView.frame.size.width - 16, 20)];
    titleLabel.text = @"隐私协议";
    titleLabel.font = [UIFont boldSystemFontOfSize:16];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor blackColor];
    [contentView addSubview:titleLabel];
    UITextView *textView = [[UITextView alloc]
        initWithFrame:CGRectMake(8, titleLabel.frame.origin.y + titleLabel.frame.size.height + 12, contentView.frame.size.width - 16, 170)];
    textView.backgroundColor = [UIColor whiteColor];
    textView.textColor = [UIColor blackColor];
    textView.font = [UIFont systemFontOfSize:13];
    textView.editable = NO;
    NSString *str = @"请您务必审慎问读、充分理解服务协议和隐私政策各条款，包括但不限于为了向您提供内容分享、媒体访问等服务，我们需要收集您的设备信息"
                    @"、媒体访问等个人信息。您可以在设置中查看、变更 "
                    @"删除个人信息并管理你的授权您可以阅读《隐私政策》了解详细信息。如果您同意，请点击同意开始接受我们的服务";
    NSRange range = [str rangeOfString:@"《隐私政策》"];
    NSMutableAttributedString *urlString = [[NSMutableAttributedString alloc] initWithString:str];
    [urlString addAttribute:NSLinkAttributeName value:@"https://privacy.qq.com/document/preview/8565a4a2d26e480187ed86b0cc81d727" range:range];
    textView.attributedText = urlString;
    [contentView addSubview:textView];
    UIButton *agreeBtn = [[UIButton alloc]
        initWithFrame:CGRectMake(20, textView.frame.origin.y + textView.frame.size.height + 20, contentView.frame.size.width - 40, 40)];
    agreeBtn.layer.cornerRadius = 20;
    agreeBtn.backgroundColor = [[UIColor alloc] initWithWhite:0 alpha:0.8];
    [agreeBtn setTitle:@"同意" forState:UIControlStateNormal];
    [agreeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    agreeBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [agreeBtn addTarget:self action:@selector(agreeAction) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:agreeBtn];
    [self addSubview:contentView];
}

- (void)agreeAction {
    [self removeFromSuperview];
    /// 同意隐私协议后，启动TPNS服务,弹出通知授权
    self.agreeHander();
}

@end
