//
//  ViewController.h
//  TPNS-Demo
//
//  Created by tyzual on 28/10/2016.
//  Copyright © 2016 tyzual. All rights reserved.
//

#import <UIKit/UIKit.h>

/// TPNS feature ViewController
@interface ViewController : UIViewController

@end
