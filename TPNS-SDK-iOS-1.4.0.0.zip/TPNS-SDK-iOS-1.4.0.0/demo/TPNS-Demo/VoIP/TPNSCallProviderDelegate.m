//
//  TPNSCallProviderDelegate.m
//  TPNS-Demo-Cloud
//
//  Created by boblv on 2022/2/22.
//  Copyright © 2022 TEG of Tencent. All rights reserved.
//

#import "TPNSCallProviderDelegate.h"
#import <CallKit/CallKit.h>
#import <UIKit/UIKit.h>
#import "TPNSVoIPManager.h"
#import "TPNSVoIPCall.h"
#import "TPNSVoIPManager.h"

/// An object that have a telephony provider
@interface TPNSCallProviderDelegate () <CXProviderDelegate>
// An object that have a telephony provider.
@property (nonatomic, strong) CXProvider *provider;
// call manager
@property (nonatomic, strong) TPNSVoIPCallManager *callManager;
@end
/// An object that represents a telephony provider
@implementation TPNSCallProviderDelegate
/// 初始化CallKit
- (instancetype)initWithTPNSVoIPCallManager:(TPNSVoIPCallManager *)callManager {
    self = [super init];
    if (self) {
        if (@available(iOS 10.0, *)) {
            CXProviderConfiguration *config = [[CXProviderConfiguration alloc] initWithLocalizedName:@"VoIP Service"];
            // 是否支持视频通话
            config.supportsVideo = true;
            config.supportedHandleTypes = [NSSet setWithObjects:@(CXHandleTypeGeneric), @(CXHandleTypePhoneNumber), nil];
            // Prevents multiple calls from being grouped.
            config.maximumCallsPerCallGroup = 1;
            // Custom ringtone sound
            config.ringtoneSound = @"voip_ring.caf";
            UIImage *image = [UIImage imageNamed:@"AppIcon"];
            NSData *imagedata = UIImagePNGRepresentation(image);
            config.iconTemplateImageData = imagedata;

            self.provider = [[CXProvider alloc] initWithConfiguration:config];
            [_provider setDelegate:self queue:nil];
            self.callManager = callManager;
        }
    }
    return self;
}

#pragma mark -唤起来电通话界面

/// 消息传给CallKit处理
/// @param uuid 通话ID
/// @param handle 通话号码
/// @param localizedCallerName 通话昵称
/// @param hasVideo 是否是视频通话
/// @param completion 系统执行回调，返回执行错误
- (void)reportNewIncomingCallWithUUID:(nonnull NSUUID *)uuid
                               handle:(nonnull NSString *)handle
                  localizedCallerName:(nonnull NSString *)localizedCallerName
                             hasVideo:(BOOL)hasVideo
                           completion:(nullable void (^)(NSError *_Nullable error))completion {
    if (@available(iOS 10.0, *)) {
        CXCallUpdate *update = [[CXCallUpdate alloc] init];
        /*
         对于由通话号码标识的呼叫者，句柄类型为CXHandleTypePhoneNumber，值为一系列数字。
         对于由电子邮件地址标识的呼叫者，句柄类型为CXHandleTypeEmailAddress，值为电子邮件地址。
         对于以任何其他方式标识的调用方，句柄类型为CXHandleTypeGeneric，
         值通常遵循某些特定于域的格式，例如用户名、数字ID或URL。
         */
        //        update.remoteHandle = [[CXHandle alloc] initWithType:CXHandleTypePhoneNumber value:handle];
        update.remoteHandle = [[CXHandle alloc] initWithType:CXHandleTypeGeneric value:handle];
        update.supportsDTMF = false;
        update.supportsHolding = false;
        update.supportsGrouping = false;
        update.supportsUngrouping = false;
        // 是否是视频通话
        update.hasVideo = hasVideo;
        if (localizedCallerName) {
            update.localizedCallerName = localizedCallerName;
        }

        [_provider reportNewIncomingCallWithUUID:uuid
                                          update:update
                                      completion:^(NSError *_Nullable error) {
                                          completion(error);
                                      }];
    }
}

#pragma mark -通话代理方法

// this is getting called
- (void)providerDidBegin:(CXProvider *)provider {
}

// Called when the provider has been reset.
- (void)providerDidReset:(nonnull CXProvider *)provider {
    /*
     End any ongoing calls if the provider resets, and remove them from the app's list of calls
     because they are no longer valid.
     */
    for (TPNSVoIPCall *call in self.callManager.calls.allValues) {
        [call endSpeakerboxCall];
    }

    // Remove all calls from the app's list of calls.
    [self.callManager removeAllCalls];
}

// an encapsulation of the act of initiating an outgoing call.
- (void)provider:(CXProvider *)provider performStartCallAction:(CXStartCallAction *)action {
    // Create and configure an instance of TPNSVoIPCall to represent the new outgoing call.
    TPNSVoIPCall *call = [[TPNSVoIPCall alloc] init];
    call.uuid = action.callUUID;
    call.handle = action.handle.value;
    call.hasVideo = action.isVideo;
    call.isOutgoing = true;

    [self.callManager addCall:call];

    [action fulfill];
}

// this is getting called when the Answer button is pressed
- (void)provider:(CXProvider *)provider performAnswerCallAction:(CXAnswerCallAction *)action {
    // Retrieve the TPNSVoIPCall instance corresponding to the action's call UUID.
    TPNSVoIPCall *call = [self.callManager callWithUUID:action.callUUID];
    if (!call) {
        [action fail];
        return;
    }
    [call answerSpeakerboxCall];

    // 通话结束后需要移除call
    [action fulfill];
}
// this is getting called when the End button is pressed
- (void)provider:(CXProvider *)provider performEndCallAction:(CXEndCallAction *)action {
    // Retrieve the TPNSVoIPCall instance corresponding to the action's call UUID.
    TPNSVoIPCall *call = [self.callManager callWithUUID:action.callUUID];
    if (!call) {
        [action fail];
        return;
    }
    // Trigger the call to be ended via the underlying network service.
    [call endSpeakerboxCall];
    // Remove the ended call from the app's list of calls.
    [self.callManager removeCall:call];
    if ([action.callUUID isEqual:[TPNSVoIPManager defaultManager].incomingCallUUID]) {
        [TPNSVoIPManager defaultManager].incomingCallUUID = nil;
    } else if ([action.callUUID isEqual:[TPNSVoIPManager defaultManager].outgoingCallUUID]) {
        [TPNSVoIPManager defaultManager].outgoingCallUUID = nil;
    }
    [action fulfill];
}

// this is getting called when the Muted button is pressed
- (void)provider:(CXProvider *)provider performSetHeldCCallAction:(CXSetHeldCallAction *)action {
    // Retrieve the TPNSVoIPCall instance corresponding to the action's call UUID.
    TPNSVoIPCall *call = [self.callManager callWithUUID:action.callUUID];
    if (!call) {
        [action fail];
        return;
    }
    // Update the SpeakerboxCall's underlying hold state.
    call.isOnHold = action.isOnHold;
    [action fulfill];
}

@end
