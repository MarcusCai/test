//
//  TPNSVoIPManager.m
//  TPNS-Demo-Cloud
//
//  Created by boblv on 2022/3/4.
//  Copyright © 2022 XG of Tencent. All rights reserved.
//

#import "TPNSVoIPManager.h"
#import "XGVoIPService.h"
#import "TPNSCallProviderDelegate.h"
#import <UIKit/UIKit.h>
#import "TPNSVoIPServicesTool.h"
#import <Intents/Intents.h>
#import "TPNSVoIPCallManager.h"
#import "TPNSCommonMethod.h"
/// TPNS VoIP Manager
@interface TPNSVoIPManager ()
/// 通话服务提供者代理
@property (nonatomic, strong) TPNSCallProviderDelegate *providerDelegate;

@end
/// TPNS VoIP Manager
@implementation TPNSVoIPManager
/// 单例
+ (instancetype)defaultManager {
    static TPNSVoIPManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!instance) {
            instance = [[TPNSVoIPManager alloc] init];
            instance.callManager = [[TPNSVoIPCallManager alloc] init];
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 10.0) {
                // 初始化CallKit
                instance.providerDelegate = [[TPNSCallProviderDelegate alloc] initWithTPNSVoIPCallManager:instance.callManager];
            }
        }
    });
    return instance;
}
#pragma mark - 注册VoIP服务
+ (void)voipRegistration {
    dispatch_queue_t mainQueue = dispatch_get_main_queue();
    PKPushRegistry *voipRegistry = [[PKPushRegistry alloc] initWithQueue:mainQueue];
    voipRegistry.delegate = [TPNSVoIPManager defaultManager];
    // Set the push type to VoIP
    voipRegistry.desiredPushTypes = [NSSet setWithObject:PKPushTypeVoIP];
}

#pragma mark - 呼入通话，VoIP Push系统代理方法及相关实现
- (void)pushRegistry:(PKPushRegistry *)registry didUpdatePushCredentials:(PKPushCredentials *)pushCredentials forType:(PKPushType)type {
    // VoIP Token上报给TPNS服务器
    [XGVoIPService registerVoIPToken:pushCredentials.token];
}

/// 系统收到VoIP消息 ios(8.0, 11.0)
- (void)pushRegistry:(PKPushRegistry *)registry didReceiveIncomingPushWithPayload:(PKPushPayload *)payload forType:(PKPushType)type {
    [self reportNewIncomingCallWithPayload:payload forType:type];
}

/// 系统收到VoIP消息 ios(11.0+)
- (void)pushRegistry:(PKPushRegistry *)registry
    didReceiveIncomingPushWithPayload:(PKPushPayload *)payload
                              forType:(PKPushType)type
                withCompletionHandler:(void (^)(void))completion {
    [self reportNewIncomingCallWithPayload:payload forType:type];
    completion();
}
/*
 Important
 On iOS 13.0 and later, if you fail to report a call to CallKit,the system will terminate your app.
 Repeatedly failing to report calls may cause the system to stop delivering any more VoIP push notifications
 to your app. If you want to initiate a VoIP call without using CallKit, register for push notifications
 using the User Notifications framework instead of PushKit. For more information, see User Notifications.
 */
/// 将消息传给CallKit处理, 苹果要求ios(13.0+)必须传给CallKit处理，否则将不能继续接收VoIP消息
- (void)reportNewIncomingCallWithPayload:(PKPushPayload *)payload forType:(PKPushType)type {
    @try {
        if (payload) {
            // 提交回执给TPNS服务器
            [XGVoIPService handleVoIPNotification:payload.dictionaryPayload];
            NSLog(@"report new incoming call with payload %@", payload);
            if (!(payload.dictionaryPayload && [payload.dictionaryPayload isKindOfClass:[NSDictionary class]])) {
                return;
            }
            NSString *customStr = payload.dictionaryPayload[@"custom"];
            NSDictionary *customContent = [TPNSCommonMethod json2Obj:customStr];
            if (customContent && [customContent isKindOfClass:[NSDictionary class]]) {
                //通话号码
                NSString *handleStr = customContent[@"handle"];
                //通话昵称
                NSString *callerName = customContent[@"callerName"];
                //通话ID
                NSString *uuidString = customContent[@"callUUID"];
                //是否视频通话
                NSNumber *hasVideo = customContent[@"hasVideo"];
                /*
                 通话类型：1:来电(iOS 10+)；本地通知显示如："XX正在邀请你视频通话"(iOS 9)
                 2:当前来电挂断(iOS 10+)；本地通知显示如："[未接听]XX邀请你视频通话"(iOS 9)
                 */
                NSNumber *callAction = customContent[@"callAction"];
                NSUUID *uuid = nil;
                if ([TPNSCommonMethod isValidNonEmptyString:uuidString]) {
                    uuid = [[NSUUID alloc] initWithUUIDString:uuidString];
                }
                if (!uuid) {
                    uuid = [NSUUID UUID];
                    NSLog(@"VoIP Push 参数异常：callUUID无法正常生成uuid");
                }
                if (!([TPNSCommonMethod isValidNonEmptyString:handleStr] && [TPNSCommonMethod isValidNonEmptyString:callerName] && hasVideo
                      && callAction)) {
                    NSLog(@"VoIP Push 参数异常：callerName、handle应非空字符串，callAction、hasVideo应非空");
                    return;
                }
                //如果已经存在，更新状态
                TPNSVoIPCall *call = [self.callManager callWithUUID:uuid];
                if (!call) {
                    call = [[TPNSVoIPCall alloc] init];
                    call.uuid = uuid;
                } else {
                    /*
                     同id，同类型的通话，属于重复消息，此处过滤，
                     iOS 13+必须要传值CallKit，此处逻辑应开发者服务端过滤,控制发送频率
                     */
                    if (call.actionType == callAction.intValue) {
                        return;
                    }
                }
                //从 iOS 13 开始，您只能使用 VoIP 推送来报告来电，其他类型会导致崩溃
                //此处限制需要开发者服务端中限制
                if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 13.0) {
                    if (callAction.intValue != TPNSVoIPCallActionTypeStart) {
                        NSLog(@"iOS 13+ 仅支持电话拨入事件，其他类型事件禁止使用，会导致App Crash！");
                        return;
                    }
                }

                TPNSVoIPCall *currentCall = [self.callManager callWithUUID:self.incomingCallUUID];
                //此处限制需要开发者服务端中限制
                if (currentCall && currentCall.actionType == callAction.intValue && [currentCall.uuid isEqual:self.incomingCallUUID]) {
                    NSLog(@"当前用户通话拨通中，重复来电");
                    return;
                }
                //此处限制需要开发者服务端中限制
                if (currentCall && callAction.intValue == TPNSVoIPCallActionTypeStart) {
                    NSLog(@"当前用户通话拨通中，此处返回服务忙碌");
                    return;
                }
                //此处限制需要开发者服务端中限制
                if (!currentCall && callAction.intValue != TPNSVoIPCallActionTypeStart) {
                    NSLog(@"当前用户未在通话中，此处返回电话事件错误");
                    return;
                }
                call.handle = handleStr;
                call.hasVideo = hasVideo.boolValue;
                call.callerName = callerName;
                call.actionType = callAction.intValue;
                //本地通知会用到该字段
                call.userInfo = customContent;
                [self actionNewIncomingCall:call];
            }
        }
    } @catch (NSException *exception) {
        NSLog(@"report new incoming call with payload exception:%@", exception);
    } @finally {
    }
}

- (void)actionNewIncomingCall:(nonnull TPNSVoIPCall *)call {
    /**
     iOS9的设备即使收到VoIP消息也无法唤起CallKit功能，对于iOS10以前的版本以下两种方案
     方案一：
     请使用APNS通知发送消息，可使用自定义本地铃声文件如：voip_ring.caf，
     如果用户未接听,使用APNS的覆盖功能将接听的进行覆盖（要标签，全推，账号包，token包推送才能覆盖）
     方案二（推荐）：
     使用VoIP通道控制CallKit\本地通知，来电铃声使用定制铃声
     */
    if (!call)
        return;
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 10.0) {
        [self actionCallKitNewIncomingCall:call];
    } else {
        [self actionLocaNotificationNewIncomingCall:call];
    }
}

- (void)actionCallKitNewIncomingCall:(nonnull TPNSVoIPCall *)call {
    switch (call.actionType) {
        case TPNSVoIPCallActionTypeStart: {
            // 默认超时120s挂断通话
            [self performSelector:@selector(incomingCallTomeOut:) withObject:call afterDelay:120];
            self.incomingCallUUID = call.uuid;
            [self reportNewIncomingCall:call
                             completion:^(NSError *_Nullable error) {
                                 /*
                                  Only add an incoming call to an app's list of calls if it's allowed, i.e., there is no error.
                                  Calls may be denied for various legitimate reasons. See CXErrorCodeIncomingCallError.
                                  */
                                 if (!error) {
                                     [self.callManager addCall:call];
                                 } else {
                                     NSLog(@"report new incoming call completion error:%@", error);
                                     self.incomingCallUUID = nil;
                                 }
                             }];
        } break;
        case TPNSVoIPCallActionTypeHangUp:
        case TPNSVoIPCallActionTypeTimeOut: {
            [TPNSVoIPManager cancelPreviousPerformRequestsWithTarget:self selector:@selector(incomingCallTomeOut:) object:call];
            //消息传给CallKit处理
            [self.callManager endWithCallUUID:self.incomingCallUUID];
            self.incomingCallUUID = nil;
        } break;
        default:
            break;
    }
}

- (void)actionLocaNotificationNewIncomingCall:(nonnull TPNSVoIPCall *)call {
    NSString *hasVideoStr = call.hasVideo ? @"视频" : @"语音";
    switch (call.actionType) {
        case TPNSVoIPCallActionTypeStart: {
            // 默认超时120s挂断通话
            [self performSelector:@selector(incomingCallTomeOut:) withObject:call afterDelay:120];
            NSString *titile = [NSString stringWithFormat:@"%@正在邀请你%@通话。。。", call.callerName, hasVideoStr];
            [TPNSVoIPServicesTool addLocalNotification:titile requestIdentifier:call.uuid.UUIDString userInfo:call.userInfo];
            [TPNSVoIPServicesTool startAudioForResource:@"voip_ring" ofType:@"caf" duration:17.0];
            self.incomingCallUUID = call.uuid;
            [self.callManager addCall:call];
        } break;
        case TPNSVoIPCallActionTypeHangUp:
        case TPNSVoIPCallActionTypeTimeOut: {
            [TPNSVoIPManager cancelPreviousPerformRequestsWithTarget:self selector:@selector(incomingCallTomeOut:) object:call];
            NSString *titile = [NSString stringWithFormat:@"[未接听]%@邀请你%@通话", call.callerName, hasVideoStr];
            [TPNSVoIPServicesTool addLocalNotification:titile requestIdentifier:call.uuid.UUIDString userInfo:call.userInfo];
            [TPNSVoIPServicesTool stopAudio];
            // Trigger the call to be ended via the underlying network service.
            [call endSpeakerboxCall];
            // Remove the ended call from the app's list of calls.
            [self.callManager removeCall:call];
            self.incomingCallUUID = nil;
        } break;
        default:
            break;
    }
}

/// 超时，挂断通话，停止铃声
- (void)incomingCallTomeOut:(nonnull TPNSVoIPCall *)call {
    call.actionType = TPNSVoIPCallActionTypeTimeOut;
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 10.0) {
        [self actionCallKitNewIncomingCall:call];
    } else {
        [self actionLocaNotificationNewIncomingCall:call];
    }
}

- (void)reportNewIncomingCall:(nonnull TPNSVoIPCall *)call completion:(nullable void (^)(NSError *_Nullable error))completion {
    //消息传给CallKit处理
    [self.providerDelegate reportNewIncomingCallWithUUID:call.uuid
                                                  handle:call.handle
                                     localizedCallerName:call.callerName
                                                hasVideo:call.hasVideo
                                              completion:completion];
}

- (void)reportNewIncomingCallWithUUID:(nonnull NSUUID *)uuid
                               handle:(nonnull NSString *)handle
                  localizedCallerName:(nonnull NSString *)localizedCallerName
                             hasVideo:(nonnull NSNumber *)hasVideo {
    if (!(uuid && handle && localizedCallerName && hasVideo)) {
        NSLog(@"CallKit 呼入通话参数异常，不能为空");
        return;
    }
    //消息传给CallKit处理
    TPNSVoIPCall *call = [self.callManager callWithUUID:uuid];
    if (!call) {
        call = [[TPNSVoIPCall alloc] init];
        call.uuid = uuid;
    }
    call.handle = handle;
    call.hasVideo = hasVideo.boolValue;
    call.callerName = localizedCallerName;
    call.actionType = TPNSVoIPCallActionTypeStart;
    [self.callManager addCall:call];
    self.incomingCallUUID = uuid;
    [self actionNewIncomingCall:call];
}

- (void)endIncomingCall {
    TPNSVoIPCall *call = [self.callManager callWithUUID:self.incomingCallUUID];
    if (!call)
        return;
    call.actionType = TPNSVoIPCallActionTypeHangUp;
    [self actionNewIncomingCall:call];
}

#pragma mark - 呼出通话（通话记录发起）
/// 处理通话记录点击事件（点击系统通话记录里收到的VoIP通话）
+ (BOOL)continueUserActivity:(nonnull NSUserActivity *)userActivity {
    if (@available(iOS 10.0, *)) {
        INInteraction *interaction = userActivity.interaction;
        ///取决于在唤起CallKit时CXCallUpdate设置的hasVideo值
        BOOL hasVideo = false;
        INPerson *contact = nil;
        if ([interaction.intent isKindOfClass:[INStartVideoCallIntent class]]) {
            hasVideo = true;
            INStartVideoCallIntent *startVideoCallIntent = (INStartVideoCallIntent *)interaction.intent;
            contact = startVideoCallIntent.contacts[0];
        } else if ([interaction.intent isKindOfClass:[INStartAudioCallIntent class]]) {
            hasVideo = false;
            INStartAudioCallIntent *startAudioCallIntent = (INStartAudioCallIntent *)interaction.intent;
            contact = startAudioCallIntent.contacts[0];
        } else {
            return false;
        }

        // 取出通话号码
        if (contact) {
            INPersonHandle *personHandle = contact.personHandle;
            NSString *handle = personHandle.value;
            NSLog(@"caller's handle is:%@ ,hasVideo:%d", handle, hasVideo);
            TPNSVoIPCallManager *callManager = [TPNSVoIPManager defaultManager].callManager;
            NSUUID *uuid = [callManager startCallWithHandle:handle hasVideo:hasVideo];
            [TPNSVoIPManager defaultManager].outgoingCallUUID = uuid;
        }

        return true;
    }

    return false;
}

#pragma mark -呼出通话

/// 开始呼出通话
/// @return 通话唯一标识
/// @param handle 通话号
- (NSUUID *)startCallWithHandle:(NSString *)handle hasVideo:(BOOL)hasVideo {
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 10.0) {
        //消息传给CallKit处理，如果当前有未结束通话，则结束通话，再拨打
        if (self.outgoingCallUUID) {
            [self endOutgoingCall];
        }
        NSUUID *uuid = [self.callManager startCallWithHandle:handle hasVideo:hasVideo];
        [TPNSVoIPManager defaultManager].outgoingCallUUID = uuid;
        return uuid;
    } else {
        NSLog(@"iOS 10以前的版本无法执行CallKit唤起");
    }
    return nil;
}

- (void)endOutgoingCall {
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 10.0) {
        //消息传给CallKit处理
        [self.callManager endWithCallUUID:self.outgoingCallUUID];
        self.outgoingCallUUID = nil;
    } else {
        NSLog(@"iOS 10以前的版本无法执行CallKit唤起");
    }
}

@end
