//
//  TPNSAudioServicesTool.h
//  TPNS-Demo-Cloud
//
//  Created by boblv on 2022/3/9.
//  Copyright © 2022 XG of Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// VoIP帮助类
@interface TPNSVoIPServicesTool : NSObject
/// 播放VoIP铃声
/// @param name 铃声文件名
/// @param ext 铃声文件后缀名
/// @param duration 铃声总时长
+ (void)startAudioForResource:(nonnull NSString *)name ofType:(nonnull NSString *)ext duration:(NSTimeInterval)duration;
/// 停止播放VoIP铃声
+ (void)stopAudio;
/// 新建VoIP本地通知示例
/// @param body 本地通知标题
/// @param requestIdentifier 本地通知唯一标识
/// @param userInfo 本地通知消息体
+ (void)addLocalNotification:(nonnull NSString *)body
           requestIdentifier:(nonnull NSString *)requestIdentifier
                    userInfo:(nonnull NSDictionary *)userInfo;
@end

NS_ASSUME_NONNULL_END
