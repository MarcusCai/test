//
//  TPNSVoIPCallManager.m
//  TPNS-Demo-Cloud
//
//  Created by boblv on 2022/3/11.
//  Copyright © 2022 XG of Tencent. All rights reserved.
//

#import "TPNSVoIPCallManager.h"
#import <CallKit/CallKit.h>
/// 通话管理类，负责缓存通话，主动发起通话
@interface TPNSVoIPCallManager ()
// A programmatic interface for interacting with and observing calls.
@property (nonatomic, strong) CXCallController *callController;
@end
/// 通话管理类，负责缓存通话，主动发起通话
@implementation TPNSVoIPCallManager

- (instancetype)init {
    self = [super init];
    if (self) {
        self.calls = [[NSMutableDictionary alloc] initWithCapacity:0];
        if (@available(iOS 10.0, *)) {
            self.callController = [[CXCallController alloc] initWithQueue:dispatch_get_main_queue()];
        }
    }

    return self;
}

#pragma mark -应用内发起通话相关操作
/// 开始通话
- (NSUUID *)startCallWithHandle:(NSString *)handle hasVideo:(BOOL)hasVideo {
    if (@available(iOS 10.0, *)) {
        NSUUID *callUUID = [NSUUID UUID];
        CXHandle *callHandle = [[CXHandle alloc] initWithType:CXHandleTypeGeneric value:handle];
        CXStartCallAction *startCallAction = [[CXStartCallAction alloc] initWithCallUUID:callUUID handle:callHandle];
        startCallAction.video = hasVideo;
        CXTransaction *transaction = [[CXTransaction alloc] init];
        [transaction addAction:startCallAction];
        [_callController requestTransaction:transaction
                                 completion:^(NSError *_Nullable error) {
                                     NSLog(@"start caller handle:%@ error:%@", handle, error);
                                 }];
        return callUUID;
    }
    return nil;
}
/// 结束通话
- (void)endWithCallUUID:(NSUUID *)callUUID {
    if (@available(iOS 10.0, *)) {
        if (!callUUID)
            return;
        CXEndCallAction *endCallAction = [[CXEndCallAction alloc] initWithCallUUID:callUUID];
        CXTransaction *transaction = [[CXTransaction alloc] init];
        [transaction addAction:endCallAction];
        [_callController requestTransaction:transaction
                                 completion:^(NSError *_Nullable error) {
                                     NSLog(@"end call completion error:%@", error);
                                 }];
    }
}
/// 静音通话
- (void)mutedWithCallUUID:(NSUUID *)callUUID muted:(BOOL)muted {
    if (@available(iOS 10.0, *)) {
        if (!callUUID)
            return;
        CXSetMutedCallAction *mutedCallAction = [[CXSetMutedCallAction alloc] initWithCallUUID:callUUID muted:muted];
        CXTransaction *transaction = [[CXTransaction alloc] init];
        [transaction addAction:mutedCallAction];
        [_callController requestTransaction:transaction
                                 completion:^(NSError *_Nullable error) {
                                     NSLog(@"muted call completion error:%@", error);
                                 }];
    }
}

/// 暂停通话
- (void)setOnHoldStatus:(NSUUID *)callUUID onHold:(BOOL)hold {
    if (@available(iOS 10.0, *)) {
        if (!callUUID)
            return;
        CXSetHeldCallAction *mutedCallAction = [[CXSetHeldCallAction alloc] initWithCallUUID:callUUID onHold:hold];
        CXTransaction *transaction = [[CXTransaction alloc] init];
        [transaction addAction:mutedCallAction];
        [_callController requestTransaction:transaction
                                 completion:^(NSError *_Nullable error) {
                                     NSLog(@"muted call completion error:%@", error);
                                 }];
    }
}

#pragma mark -通话缓存相关操作

- (void)addCall:(TPNSVoIPCall *)call {
    if (!call)
        return;
    [self.calls setObject:call forKey:call.uuid.UUIDString];
}

- (void)removeCall:(TPNSVoIPCall *)call {
    if (!call)
        return;
    [self.calls removeObjectForKey:call.uuid.UUIDString];
}

- (TPNSVoIPCall *)callWithUUID:(NSUUID *)uuid {
    if (!uuid)
        return nil;
    return [self.calls objectForKey:uuid.UUIDString];
}

- (void)removeAllCalls {
    [self.calls removeAllObjects];
}

@end
