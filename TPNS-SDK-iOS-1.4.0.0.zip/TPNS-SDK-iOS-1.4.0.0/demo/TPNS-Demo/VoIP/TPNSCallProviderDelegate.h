//
//  TPNSCallProviderDelegate.h
//  TPNS-Demo-Cloud
//
//  Created by boblv on 2022/2/22.
//  Copyright © 2022 TEG of Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TPNSVoIPCallManager.h"

NS_ASSUME_NONNULL_BEGIN

/// An object that have a telephony provider
@interface TPNSCallProviderDelegate : NSObject
/// 初始化
- (instancetype)initWithTPNSVoIPCallManager:(TPNSVoIPCallManager *)callManager;
/// 消息传给CallKit处理
/// @param uuid 通话ID
/// @param handle 通话号码
/// @param localizedCallerName 通话昵称
/// @param hasVideo 是否是视频通话
/// @param completion 系统执行回调，返回执行错误
- (void)reportNewIncomingCallWithUUID:(nonnull NSUUID *)uuid
                               handle:(nonnull NSString *)handle
                  localizedCallerName:(nonnull NSString *)localizedCallerName
                             hasVideo:(BOOL)hasVideo
                           completion:(nullable void (^)(NSError *_Nullable error))completion;
@end

NS_ASSUME_NONNULL_END
