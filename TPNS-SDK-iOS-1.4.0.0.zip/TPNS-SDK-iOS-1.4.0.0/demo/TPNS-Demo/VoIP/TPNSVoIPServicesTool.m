//
//  TPNSAudioServicesTool.m
//  TPNS-Demo-Cloud
//
//  Created by boblv on 2022/3/9.
//  Copyright © 2022 XG of Tencent. All rights reserved.
//

#import "TPNSVoIPServicesTool.h"
#import <AudioToolbox/AudioToolbox.h>
#import "XGLocalNotification.h"
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_10_0
#import <UserNotifications/UserNotifications.h>
#endif
#import <UIKit/UIKit.h>
/// VoIP帮助类
@implementation TPNSVoIPServicesTool
//声音
static SystemSoundID tpnsVoIPSound;
//是否已经有一个待播放声音
static BOOL isTPNSVoIPSoundExist;
//声音时长
static NSTimeInterval tpnsVoIPSoundTime;

/// 开始播放的时候调用
+ (void)startAudioForResource:(nonnull NSString *)name ofType:(nonnull NSString *)ext duration:(NSTimeInterval)duration {
    tpnsVoIPSoundTime = duration;
    NSString *path = [[NSBundle mainBundle] pathForResource:name ofType:ext];
    AudioServicesCreateSystemSoundID((__bridge CFURLRef)[NSURL fileURLWithPath:path], &tpnsVoIPSound);
    AudioServicesAddSystemSoundCompletion(kSystemSoundID_Vibrate, NULL, NULL, vibrationCompleteCallback, NULL);
    AudioServicesAddSystemSoundCompletion(tpnsVoIPSound, NULL, NULL, soundCompleteCallback, NULL);
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    AudioServicesPlaySystemSound(tpnsVoIPSound);
}

+ (void)stopAudio {
    stopRingAndVibration();
}

static void stopRingAndVibration(void) {
    AudioServicesRemoveSystemSoundCompletion(kSystemSoundID_Vibrate);
    AudioServicesRemoveSystemSoundCompletion(tpnsVoIPSound);
    AudioServicesDisposeSystemSoundID(kSystemSoundID_Vibrate);
    AudioServicesDisposeSystemSoundID(tpnsVoIPSound);
}

void vibrationCompleteCallback(SystemSoundID sound, void *clientData) {
    if (!isTPNSVoIPSoundExist) {
        isTPNSVoIPSoundExist = true;
        //音频文件voip_ring.caf的声音总时长为17s,如果替换文件需要修改时长
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(tpnsVoIPSoundTime * NSEC_PER_SEC)), dispatch_get_global_queue(0, 0), ^{
            AudioServicesPlaySystemSound(sound);
            isTPNSVoIPSoundExist = false;
        });
    }
}

void soundCompleteCallback(SystemSoundID sound, void *clientData) {
    //    单次播放
    //    stopRingAndVibration();
    //循环播放
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    AudioServicesPlaySystemSound(tpnsVoIPSound);
}

/// 新建本地通知示例
+ (void)addLocalNotification:(nonnull NSString *)body
           requestIdentifier:(nonnull NSString *)requestIdentifier
                    userInfo:(nonnull NSDictionary *)userInfo {
    XGNotificationContent *content = [[XGNotificationContent alloc] init];
    content.body = body;
    /// 通知自定义key-value
    /// 注意：您如果需要通过TPNS统一接收消息回调及点击回调做业务处理，请通过xg字段msgtype为9去区分。
    content.userInfo = userInfo;

    if ([userInfo isKindOfClass:[NSDictionary class]]) {
        NSDictionary *aps = userInfo[@"aps"];
        if ([aps isKindOfClass:[NSDictionary class]]) {
            /// 设置角标
            NSNumber *badge = aps[@"badge"];
            content.badge = badge;
            /// 设置分组标识
            NSString *threadId = userInfo[@"aps"][@"thread-id"];
            content.threadIdentifier = threadId;
        }
    }

    //此处可以替换没有声音的音频文件
    content.sound = @"no_sound.m4a";
    /// 通知展示时机类
    XGNotificationTrigger *trigger = [[XGNotificationTrigger alloc] init];
    trigger.timeInterval = 1;                                   /// iOS10+设置,也可通过dateComponents来进行设置
    trigger.fireDate = [NSDate dateWithTimeIntervalSinceNow:1]; /// 低于iOS10设置

    /// 通知请求类
    XGNotificationRequest *request = [[XGNotificationRequest alloc] init];
    /// 通知标识必须赋值
    request.requestIdentifier = requestIdentifier;
    request.content = content;
    request.trigger = trigger;
    [XGLocalNotification addNotification:request];
}

@end
