//
//  TPNSVoIPCall.h
//  TPNS-Demo-Cloud
//
//  Created by boblv on 2022/3/11.
//  Copyright © 2022 XG of Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 @brief 拨入通话事件
 */
typedef NS_ENUM(NSUInteger, TPNSVoIPCallActionType) {
    TPNSVoIPCallActionTypeNone = 0,   //无事件
    TPNSVoIPCallActionTypeStart = 1,  //拨入
    TPNSVoIPCallActionTypeHangUp = 2, //挂断
    TPNSVoIPCallActionTypeTimeOut = 3 //超时
};
/// VoIP通话
@interface TPNSVoIPCall : NSObject

/// 当前通话唯一标识
@property (nonatomic, strong) NSUUID *uuid;
/// 当前通话号码
@property (nonatomic, strong) NSString *handle;
/// 当前通话来电者昵称
@property (nonatomic, strong) NSString *callerName;
/// 当前通话信息
@property (nonatomic, strong) NSDictionary *userInfo;
/// 当前通话是否属于视频通话
@property (nonatomic, assign) BOOL hasVideo;
/// 呼出通话
@property (nonatomic, assign) BOOL isOutgoing;
/// 通话执行类型
@property (nonatomic, assign) TPNSVoIPCallActionType actionType;
/// 暂停通话
@property (nonatomic, assign) BOOL isOnHold;
/// 应答
- (void)answerSpeakerboxCall;
/// 挂断
- (void)endSpeakerboxCall;

@end

NS_ASSUME_NONNULL_END
