//
//  TPNSVoIPManager.h
//  TPNS-Demo-Cloud
//
//  Created by boblv on 2022/3/4.
//  Copyright © 2022 XG of Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PushKit/PushKit.h>
@class TPNSVoIPCallManager;
NS_ASSUME_NONNULL_BEGIN
/// TPNS VoIP Manager
@interface TPNSVoIPManager : NSObject <PKPushRegistryDelegate>
/// 通话服务缓存及呼出
@property (nonatomic, strong) TPNSVoIPCallManager *callManager;
/// 当前呼入通话唯一标识
@property (nonatomic, strong, nullable) NSUUID *incomingCallUUID;
/// 当前呼出通话唯一标识
@property (nonatomic, strong, nullable) NSUUID *outgoingCallUUID;
/// 单例
+ (instancetype)defaultManager;
/// 注册VoIP服务
+ (void)voipRegistration;
/// 处理通话记录点击事件（点击系统通话记录里收到的VoIP通话）
+ (BOOL)continueUserActivity:(nonnull NSUserActivity *)userActivity;

/// 呼入通话
/// @param uuid 通话ID
/// @param handle 通话号码
/// @param localizedCallerName 通话昵称
- (void)reportNewIncomingCallWithUUID:(nonnull NSUUID *)uuid
                               handle:(nonnull NSString *)handle
                  localizedCallerName:(nonnull NSString *)localizedCallerName
                             hasVideo:(nonnull NSNumber *)hasVideo;
/// 挂断播出呼入通话
- (void)endIncomingCall;

/// 呼出通话
/// @return 通话唯一标识
/// @param handle 通话号
- (NSUUID *)startCallWithHandle:(NSString *)handle hasVideo:(BOOL)hasVideo;
// 挂断当前呼出通话
- (void)endOutgoingCall;

@end

NS_ASSUME_NONNULL_END
