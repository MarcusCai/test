//
//  TPNSVoIPCallManager.h
//  TPNS-Demo-Cloud
//
//  Created by boblv on 2022/3/11.
//  Copyright © 2022 XG of Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TPNSVoIPCall.h"
NS_ASSUME_NONNULL_BEGIN

/// 通话管理类，负责缓存通话，主动发起通话
@interface TPNSVoIPCallManager : NSObject
/// 通话缓存
@property (nonatomic, strong) NSMutableDictionary *calls;
/// 开始通话
/// @return 通话唯一标识
/// @param handle 通话号
/// @param hasVideo 视频通话
- (NSUUID *)startCallWithHandle:(NSString *)handle hasVideo:(BOOL)hasVideo;

/// 结束通话
/// @param callUUID 通话唯一标识
- (void)endWithCallUUID:(NSUUID *)callUUID;
/// 静音通话
- (void)mutedWithCallUUID:(NSUUID *)callUUID muted:(BOOL)muted;
/// 暂停通话
- (void)setOnHoldStatus:(NSUUID *)callUUID onHold:(BOOL)hold;

/// 保存通话到缓存
- (void)addCall:(TPNSVoIPCall *)call;
/// 缓存中移除通话
- (void)removeCall:(TPNSVoIPCall *)call;
/// 获取缓存中通话
- (TPNSVoIPCall *)callWithUUID:(NSUUID *)uuid;
/// 移除缓存中通话
- (void)removeAllCalls;

@end

NS_ASSUME_NONNULL_END
