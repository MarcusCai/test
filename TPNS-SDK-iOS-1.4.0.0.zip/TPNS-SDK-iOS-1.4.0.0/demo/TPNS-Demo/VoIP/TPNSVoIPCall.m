//
//  TPNSVoIPCall.m
//  TPNS-Demo-Cloud
//
//  Created by boblv on 2022/3/11.
//  Copyright © 2022 XG of Tencent. All rights reserved.
//

#import "TPNSVoIPCall.h"
/// VoIP通话
@implementation TPNSVoIPCall

- (void)answerSpeakerboxCall {
    NSLog(@"answerSpeakerboxCall");
}

- (void)endSpeakerboxCall {
    NSLog(@"endSpeakerboxCall");
}

@end
