//
//  AppDelegate+XGConfig.h
//  TPNS-Demo-Cloud
//
//  Created by rockzuo on 2019/12/3.
//  Copyright © 2019 XG of Tencent. All rights reserved.
//

#import "AppDelegate.h"
#import "XGPush.h"

NS_ASSUME_NONNULL_BEGIN

#define TPNS_ACCESS_ID 1600007893

#define TPNS_ACCESS_KEY @"IX4BGYYG8L4L"

#define TPNS_AUTHOR_CUSTOM /// 当您需要自定义通知权限授权弹框弹出时机时打开此开关
//#define TPNS_VoIP           /// VoIP服务开关，如需使用，解除该行代码注释

/// The centralized point of control and coordination for apps running in iOS. TPNS SDK start。
@interface AppDelegate (XGConfig) <XGPushDelegate>

/// start TPNS SDK
- (void)xgStart;

@end

NS_ASSUME_NONNULL_END
