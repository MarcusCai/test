//
//  NotificationViewController.h
//  XGContent
//
//  Created by uwei on 09/08/2017.
//  Copyright © 2017 tyzual. All rights reserved.
//

#import <UIKit/UIKit.h>

/// content UIViewController
@interface NotificationViewController : UIViewController

@end
